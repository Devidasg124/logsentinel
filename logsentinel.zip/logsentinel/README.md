<div align="center">

# 🛡️ LogSentinel

**Lightweight, dependency-free intrusion detection for SSH and web server logs, with every finding mapped to MITRE ATT&CK.**

[![CI](https://github.com/YOUR_USERNAME/logsentinel/actions/workflows/ci.yml/badge.svg)](https://github.com/YOUR_USERNAME/logsentinel/actions/workflows/ci.yml)
![Python](https://img.shields.io/badge/python-3.11%20%7C%203.12%20%7C%203.13-blue)
![Dependencies](https://img.shields.io/badge/dependencies-0-brightgreen)
![Coverage](https://img.shields.io/badge/coverage-96%25-brightgreen)
![License](https://img.shields.io/badge/license-MIT-green)

</div>

LogSentinel reads raw `auth.log` and Nginx/Apache access logs and finds attacker behaviour in them: brute-force, password spraying, **successful logins after a brute-force**, SQL injection, path traversal, command injection, directory scanning and request floods. It produces a ranked report as terminal output, JSON (for SIEM / pipelines) or a self-contained HTML page.

It uses only the Python standard library, so you can drop it onto any server and run it.

![HTML report](docs/report-screenshot.png)

---

## ✨ Features

| | |
|---|---|
| **7 detection rules** | SSH brute force, username enumeration, post-brute-force compromise, web attack signatures, content discovery, scanner user-agents, request floods |
| **MITRE ATT&CK mapping** | Every finding carries a technique ID (T1110.001, T1078, T1190, T1595.003, …) linked in the HTML report |
| **Context-aware severity** | A SQLi or traversal request that got a **2xx response** is escalated, because it probably worked |
| **Evasion resistant** | URL paths are decoded twice to defeat double-encoding (`%252e%252e%252f`) |
| **Sliding-window engine** | O(n) two-pointer and deque algorithms, so it handles large logs quickly |
| **Auto-detected formats** | Classic syslog, ISO-8601 rsyslog, Nginx/Apache combined, `.gz` rotated logs, stdin |
| **Fully configurable** | TOML config with strict validation, per-rule thresholds and a CIDR allowlist |
| **CI-friendly** | `--fail-on high` returns exit code 1, so it can gate a pipeline |
| **Zero dependencies** | Pure standard library (`tomllib`, `ipaddress`, `dataclasses`, …) |

## 🚀 Quick start

```bash
git clone https://github.com/YOUR_USERNAME/logsentinel.git
cd logsentinel
pip install -e .

# scan the bundled sample logs
logsentinel scan samples/auth.log samples/access.log --year 2026
```

```text
LogSentinel - 12 finding(s): 4 critical, 3 high, 2 medium, 3 low
Parsed 808 lines -> 798 events (10 unrecognised) from 2 input(s)

SEVERITY  RULE        SOURCE IP         COUNT  FIRST SEEN (UTC)     TITLE
-------------------------------------------------------------------------
CRITICAL  LS-SSH-003  203.0.113.5          43  2026-11-10 02:47:00  Successful SSH login after repeated failures
          └─ user=root; failures_before_success=42; lookback_seconds=3600  [ATT&CK T1078]
CRITICAL  LS-WEB-001  203.0.113.44          4  2026-11-10 02:55:00  Web attack: sql injection
          └─ category=sql_injection; responses_2xx=1; ...  [ATT&CK T1190]
HIGH      LS-SSH-001  203.0.113.5          42  2026-11-10 02:47:00  SSH brute-force attempt
          └─ total_failures=42; peak_in_window=31; window_seconds=60; top_targeted_users=root×42  [ATT&CK T1110.001]
...
```

On a real server:

```bash
sudo logsentinel scan /var/log/auth.log /var/log/nginx/access.log* -f html -o report.html
```

## 🧭 Usage

```text
logsentinel scan FILE [FILE ...] [options]

  -c, --config PATH        TOML config (default: built-in defaults)
  -f, --format FORMAT      text | json | html          (default: text)
  -o, --output PATH        write report to a file
  --min-severity LEVEL     hide findings below LEVEL   (default: low)
  --fail-on LEVEL          exit 1 if any finding >= LEVEL (default: none)
  --year YEAR              year for syslog lines, which omit it
  --no-color               plain output

logsentinel rules [-c CONFIG]   list detectors and their effective settings
```

**Exit codes:** `0` = OK · `1` = findings at or above `--fail-on` · `2` = usage, config or I/O error.

## 🔍 Detection rules

| ID | Rule | ATT&CK | Triggers when… |
|----|------|--------|----------------|
| `LS-SSH-001` | SSH brute force | [T1110.001](https://attack.mitre.org/techniques/T1110/001/) | ≥ 5 failed logins from one IP within 60 s |
| `LS-SSH-002` | Username enumeration / spraying | [T1110.003](https://attack.mitre.org/techniques/T1110/003/) | ≥ 4 distinct usernames from one IP within 5 min |
| `LS-SSH-003` | Login after failures (likely compromise) | [T1078](https://attack.mitre.org/techniques/T1078/) | Successful login from an IP with ≥ 5 failures in the last hour |
| `LS-WEB-001` | Web attack signatures | [T1190](https://attack.mitre.org/techniques/T1190/) | SQLi, XSS, path traversal, command injection, `.env`/`.git` probes |
| `LS-WEB-002` | Content discovery | [T1595.003](https://attack.mitre.org/techniques/T1595/003/) | ≥ 20 × 404 from one IP within 60 s |
| `LS-WEB-003` | Offensive tool user-agent | [T1595.002](https://attack.mitre.org/techniques/T1595/002/) | sqlmap, nikto, gobuster, nuclei, ffuf, … |
| `LS-WEB-004` | Request flood | [T1499](https://attack.mitre.org/techniques/T1499/) | ≥ 300 requests from one IP within 60 s |

Every threshold can be tuned in [`rules/default.toml`](rules/default.toml).

## ⚙️ Configuration

```toml
[allowlist]
networks = ["10.0.0.0/8", "203.0.113.10/32"]   # never alert on these

[brute_force]
threshold = 10
window_seconds = 120

[request_flood]
enabled = false
```

The config is validated strictly. A typo such as `treshold` or a negative value fails immediately with a clear message instead of being silently ignored.

## 🏗️ Architecture

```
            ┌───────────┐   ┌───────────────┐   ┌──────────────┐   ┌──────────────┐
 log files ─▶  parsers   ├──▶  Event stream  ├──▶  detectors    ├──▶  report       │
 (.log/.gz) │ auto-detect│   │ normalised,   │   │ sliding-     │   │ text / json  │
 stdin      │ ssh / http │   │ UTC, sorted   │   │ window rules │   │ / html       │
            └───────────┘   └───────────────┘   └──────┬───────┘   └──────────────┘
                                                        │
                                       config.toml ─────┘  (thresholds, allowlist)
```

```
src/logsentinel/
├── models.py      # Event, Finding, Severity
├── parsers.py     # syslog / ISO / combined-log parsers
├── detectors.py   # detection rules (each one is a typed dataclass)
├── config.py      # TOML loading and validation
├── engine.py      # parse → detect → filter → rank pipeline
├── report.py      # text / JSON / HTML renderers
└── cli.py         # argparse CLI
```

**Design notes**

- **Detectors are dataclasses.** Their fields *are* their config options, so adding a rule means writing one class. Config parsing, validation and the `rules` listing work automatically.
- **Everything is normalised to UTC** at parse time, so events from different sources and time zones sort and correlate correctly.
- **The HTML output is escaped.** Attackers control log content, so every value is passed through `html.escape`. A test checks that a logged `<script>` payload cannot execute in the report.
- **Sample data uses RFC 5737 documentation IPs** (`192.0.2.0/24`, `198.51.100.0/24`, `203.0.113.0/24`), so no real host is implicated.

## 🧪 Development

```bash
pip install -e ".[dev]"
pytest --cov=logsentinel        # 43 tests, ~96% coverage
ruff check .                    # lint
python scripts/generate_samples.py   # regenerate demo logs
```

CI runs lint, tests and a smoke scan on Python 3.11, 3.12 and 3.13 for every push.

## 🗺️ Roadmap

- [ ] GeoIP / ASN enrichment for source IPs
- [ ] Windows Event Log (4625/4624) parser
- [ ] Live `--follow` mode (tail -f) with alerting to Slack/Discord webhooks
- [ ] Sigma rule import
- [ ] Cross-source correlation (same IP scanning the web *and* brute-forcing SSH)

## ⚠️ Disclaimer

LogSentinel is a defensive tool for analysing logs **you own or are authorised to review**. Signature-based detection can produce false positives and miss novel attacks. Use it alongside your other security controls, not as a replacement for them.

## 📄 License

[MIT](LICENSE) © 2026 Prashant
