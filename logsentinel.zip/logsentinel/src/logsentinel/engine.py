"""Analysis pipeline: read -> parse -> detect -> filter -> rank."""

from __future__ import annotations

from collections import Counter
from collections.abc import Iterable
from dataclasses import dataclass, field
from datetime import UTC, datetime

from .config import Config
from .models import Event, Finding, Severity
from .parsers import parse_line


@dataclass
class ParseStats:
    lines_total: int = 0
    events: int = 0
    unparsed: int = 0
    by_source: Counter[str] = field(default_factory=Counter)

    def to_dict(self) -> dict[str, object]:
        return {
            "lines_total": self.lines_total,
            "events": self.events,
            "unparsed": self.unparsed,
            "by_source": dict(self.by_source),
        }


@dataclass
class AnalysisResult:
    findings: list[Finding]
    stats: ParseStats
    inputs: list[str]
    generated_at: datetime = field(default_factory=lambda: datetime.now(UTC))

    def severity_counts(self) -> dict[str, int]:
        counts = Counter(f.severity.name for f in self.findings)
        return {s.name: counts.get(s.name, 0) for s in sorted(Severity, reverse=True)}

    def to_dict(self) -> dict[str, object]:
        return {
            "generated_at": self.generated_at.isoformat(),
            "inputs": self.inputs,
            "stats": self.stats.to_dict(),
            "summary": self.severity_counts(),
            "findings": [f.to_dict() for f in self.findings],
        }


def parse_sources(
    sources: Iterable[tuple[str, Iterable[str]]], year: int
) -> tuple[list[Event], ParseStats, list[str]]:
    stats = ParseStats()
    events: list[Event] = []
    names: list[str] = []
    for name, lines in sources:
        names.append(name)
        for line in lines:
            if not line.strip():
                continue
            stats.lines_total += 1
            event = parse_line(line, year)
            if event is None:
                stats.unparsed += 1
                continue
            events.append(event)
            stats.by_source[event.source] += 1
    stats.events = len(events)
    events.sort(key=lambda e: e.timestamp)
    return events, stats, names


def analyze(
    sources: Iterable[tuple[str, Iterable[str]]],
    config: Config,
    *,
    year: int | None = None,
    min_severity: Severity = Severity.LOW,
) -> AnalysisResult:
    events, stats, names = parse_sources(sources, year or datetime.now(UTC).year)
    findings: list[Finding] = []
    for detector in config.detectors:
        findings.extend(detector.detect(events))

    findings = [f for f in findings if f.severity >= min_severity and not config.is_allowed(f.ip)]
    findings.sort(key=lambda f: (-f.severity, f.first_seen, f.rule_id))
    return AnalysisResult(findings=findings, stats=stats, inputs=names)
