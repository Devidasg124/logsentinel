"""Command-line interface.

Exit codes:
    0  scan finished, nothing at or above --fail-on
    1  scan finished, findings at or above --fail-on
    2  usage / configuration / I/O error
"""

from __future__ import annotations

import argparse
import gzip
import os
import sys
from collections.abc import Iterator, Sequence
from contextlib import ExitStack
from pathlib import Path
from typing import TextIO

from . import __version__
from .config import load_config
from .detectors import REGISTRY, ConfigError
from .engine import analyze
from .models import Severity
from .report import render_html, render_json, render_text

SEVERITY_CHOICES = [s.name.lower() for s in Severity]


def _open_log(path: str, stack: ExitStack) -> Iterator[str]:
    if path == "-":
        return iter(sys.stdin)
    p = Path(path)
    if p.suffix == ".gz":
        fh: TextIO = stack.enter_context(gzip.open(p, "rt", encoding="utf-8", errors="replace"))  # noqa: SIM115
    else:
        fh = stack.enter_context(open(p, encoding="utf-8", errors="replace"))  # noqa: SIM115
    return iter(fh)


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="logsentinel",
        description="Detect brute-force, scanning and web attacks in SSH and web server logs.",
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    scan = sub.add_parser("scan", help="analyse one or more log files")
    scan.add_argument("files", nargs="+", help="log files (.log, .gz, or '-' for stdin)")
    scan.add_argument("-c", "--config", help="TOML config file (default: built-in defaults)")
    scan.add_argument("-f", "--format", choices=["text", "json", "html"], default="text")
    scan.add_argument("-o", "--output", help="write report to this file instead of stdout")
    scan.add_argument(
        "--min-severity", choices=SEVERITY_CHOICES, default="low", help="hide findings below this"
    )
    scan.add_argument(
        "--fail-on",
        choices=[*SEVERITY_CHOICES, "none"],
        default="none",
        help="exit with code 1 if any finding is at or above this severity (useful in CI)",
    )
    scan.add_argument(
        "--year", type=int, help="year for syslog timestamps that omit it (default: current year)"
    )
    scan.add_argument("--no-color", action="store_true", help="disable ANSI colours")

    rules = sub.add_parser("rules", help="list detectors and their effective settings")
    rules.add_argument("-c", "--config", help="TOML config file")
    return parser


def _cmd_rules(args: argparse.Namespace) -> int:
    config = load_config(args.config)
    enabled = {d.name: d for d in config.detectors}
    for name, cls in REGISTRY.items():
        det = enabled.get(name)
        state = "on " if det else "off"
        opts = ", ".join(f"{k}={v}" for k, v in det.options().items()) if det else "-"
        print(f"[{state}] {cls.rule_id}  {name:<20} ATT&CK {cls.mitre or '-':<10} {opts}")
        print(f"       {cls.description}")
    if config.allowlist:
        print(f"\nallowlist: {', '.join(str(n) for n in config.allowlist)}")
    return 0


def _cmd_scan(args: argparse.Namespace) -> int:
    config = load_config(args.config)
    with ExitStack() as stack:
        sources = [(f, _open_log(f, stack)) for f in args.files]
        result = analyze(
            sources,
            config,
            year=args.year,
            min_severity=Severity.parse(args.min_severity),
        )

    if args.format == "json":
        output = render_json(result)
    elif args.format == "html":
        output = render_html(result)
    else:
        use_color = (
            not args.no_color and args.output is None and sys.stdout.isatty() and "NO_COLOR" not in os.environ
        )
        output = render_text(result, color=use_color)

    if args.output:
        Path(args.output).write_text(output, encoding="utf-8")
        print(f"Report written to {args.output} ({len(result.findings)} findings)", file=sys.stderr)
    else:
        print(output)

    if args.fail_on != "none":
        threshold = Severity.parse(args.fail_on)
        if any(f.severity >= threshold for f in result.findings):
            return 1
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    try:
        if args.command == "rules":
            return _cmd_rules(args)
        return _cmd_scan(args)
    except ConfigError as exc:
        print(f"logsentinel: config error: {exc}", file=sys.stderr)
        return 2
    except OSError as exc:
        print(f"logsentinel: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
