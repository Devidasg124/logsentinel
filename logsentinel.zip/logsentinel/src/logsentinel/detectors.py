"""Detection rules.

Each detector is a small dataclass whose fields are its tunable options. That
makes every option configurable from TOML with zero boilerplate, and lets the
config loader validate option names and types automatically.

Detectors receive the full, time-sorted list of events and return findings.
"""

from __future__ import annotations

import re
from abc import ABC, abstractmethod
from collections import Counter, defaultdict, deque
from collections.abc import Callable, Iterable
from dataclasses import dataclass, fields
from datetime import datetime, timedelta
from typing import Any, ClassVar
from urllib.parse import unquote_plus

from .models import Event, Finding, Severity

MAX_EVIDENCE = 5


class ConfigError(ValueError):
    """Raised when a detector or config file is misconfigured."""


# --- helpers ---------------------------------------------------------------


def group_by_ip(events: Iterable[Event], predicate: Callable[[Event], bool]) -> dict[str, list[Event]]:
    """Group matching events by source IP, preserving time order."""
    groups: dict[str, list[Event]] = defaultdict(list)
    for event in events:
        if predicate(event):
            groups[event.ip].append(event)
    return groups


def peak_in_window(times: list[datetime], window: timedelta) -> int:
    """Maximum number of timestamps that fall inside any sliding ``window``.

    ``times`` must be sorted. Runs in O(n) using a two-pointer sweep.
    """
    best = left = 0
    for right, current in enumerate(times):
        while current - times[left] > window:
            left += 1
        best = max(best, right - left + 1)
    return best


# --- base class ------------------------------------------------------------


@dataclass
class Detector(ABC):
    name: ClassVar[str]
    rule_id: ClassVar[str]
    title: ClassVar[str]
    mitre: ClassVar[str | None] = None
    description: ClassVar[str] = ""

    def __post_init__(self) -> None:
        for f in fields(self):
            value = getattr(self, f.name)
            if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
                raise ConfigError(
                    f"[{self.name}] option {f.name!r} must be a positive integer, got {value!r}"
                )

    @classmethod
    def option_names(cls) -> list[str]:
        return [f.name for f in fields(cls)]

    def options(self) -> dict[str, Any]:
        return {f.name: getattr(self, f.name) for f in fields(self)}

    @abstractmethod
    def detect(self, events: list[Event]) -> list[Finding]: ...

    def _finding(
        self,
        ip: str,
        events: list[Event],
        severity: Severity,
        details: dict[str, Any],
        *,
        title: str | None = None,
        rule_id: str | None = None,
        mitre: str | None = None,
    ) -> Finding:
        return Finding(
            rule_id=rule_id or self.rule_id,
            title=title or self.title,
            severity=severity,
            ip=ip,
            first_seen=events[0].timestamp,
            last_seen=events[-1].timestamp,
            count=len(events),
            mitre=mitre or self.mitre,
            details=details,
            evidence=[e.raw for e in events[:MAX_EVIDENCE]],
        )


# --- SSH detectors ---------------------------------------------------------


@dataclass
class BruteForceDetector(Detector):
    name: ClassVar[str] = "brute_force"
    rule_id: ClassVar[str] = "LS-SSH-001"
    title: ClassVar[str] = "SSH brute-force attempt"
    mitre: ClassVar[str] = "T1110.001"
    description: ClassVar[str] = "Many failed SSH logins from one IP within a short window."

    threshold: int = 5
    window_seconds: int = 60

    def detect(self, events: list[Event]) -> list[Finding]:
        window = timedelta(seconds=self.window_seconds)
        findings = []
        failures = group_by_ip(events, lambda e: e.source == "ssh" and e.action == "auth_failure")
        for ip, evs in failures.items():
            peak = peak_in_window([e.timestamp for e in evs], window)
            if peak < self.threshold:
                continue
            severity = Severity.HIGH if peak >= self.threshold * 4 else Severity.MEDIUM
            users = Counter(e.user for e in evs if e.user)
            findings.append(
                self._finding(
                    ip,
                    evs,
                    severity,
                    {
                        "total_failures": len(evs),
                        "peak_in_window": peak,
                        "window_seconds": self.window_seconds,
                        "top_targeted_users": dict(users.most_common(5)),
                    },
                )
            )
        return findings


@dataclass
class UserEnumerationDetector(Detector):
    name: ClassVar[str] = "user_enumeration"
    rule_id: ClassVar[str] = "LS-SSH-002"
    title: ClassVar[str] = "SSH username enumeration / password spraying"
    mitre: ClassVar[str] = "T1110.003"
    description: ClassVar[str] = "One IP trying many distinct usernames within a window."

    distinct_users: int = 4
    window_seconds: int = 300

    def detect(self, events: list[Event]) -> list[Finding]:
        span = timedelta(seconds=self.window_seconds)
        findings = []
        attempts = group_by_ip(
            events,
            lambda e: e.source == "ssh" and e.action in {"auth_failure", "invalid_user"} and bool(e.user),
        )
        for ip, evs in attempts.items():
            window: deque[Event] = deque()
            in_window: Counter[str] = Counter()
            peak = 0
            for event in evs:
                window.append(event)
                in_window[event.user or ""] += 1
                while event.timestamp - window[0].timestamp > span:
                    old = window.popleft()
                    in_window[old.user or ""] -= 1
                    if in_window[old.user or ""] == 0:
                        del in_window[old.user or ""]
                peak = max(peak, len(in_window))
            if peak < self.distinct_users:
                continue
            all_users = sorted({e.user for e in evs if e.user})
            severity = Severity.HIGH if peak >= self.distinct_users * 2 else Severity.MEDIUM
            findings.append(
                self._finding(
                    ip,
                    evs,
                    severity,
                    {
                        "distinct_users_total": len(all_users),
                        "peak_distinct_in_window": peak,
                        "window_seconds": self.window_seconds,
                        "sample_users": all_users[:10],
                    },
                )
            )
        return findings


@dataclass
class CompromiseDetector(Detector):
    name: ClassVar[str] = "compromise"
    rule_id: ClassVar[str] = "LS-SSH-003"
    title: ClassVar[str] = "Successful SSH login after repeated failures"
    mitre: ClassVar[str] = "T1078"
    description: ClassVar[str] = (
        "An IP that racked up many failures then logged in successfully - likely compromise."
    )

    failure_threshold: int = 5
    lookback_seconds: int = 3600

    def detect(self, events: list[Event]) -> list[Finding]:
        lookback = timedelta(seconds=self.lookback_seconds)
        findings = []
        ssh = group_by_ip(events, lambda e: e.source == "ssh" and e.action != "invalid_user")
        for ip, evs in ssh.items():
            failures: deque[Event] = deque()
            reported_users: set[str | None] = set()
            for event in evs:
                if event.action == "auth_failure":
                    failures.append(event)
                    continue
                if event.action != "auth_success":
                    continue
                while failures and event.timestamp - failures[0].timestamp > lookback:
                    failures.popleft()
                if len(failures) >= self.failure_threshold and event.user not in reported_users:
                    reported_users.add(event.user)
                    chain = [*list(failures)[-(MAX_EVIDENCE - 1) :], event]
                    finding = self._finding(
                        ip,
                        chain,
                        Severity.CRITICAL,
                        {
                            "user": event.user,
                            "failures_before_success": len(failures),
                            "lookback_seconds": self.lookback_seconds,
                        },
                    )
                    finding.first_seen = failures[0].timestamp
                    finding.count = len(failures) + 1
                    findings.append(finding)
        return findings


# --- HTTP detectors --------------------------------------------------------

WEB_SIGNATURES: dict[str, tuple[Severity, re.Pattern[str]]] = {
    "sql_injection": (
        Severity.HIGH,
        re.compile(
            r"(\bunion\b.{0,30}\bselect\b|'\s*or\s*'?\d*'?\s*=\s*'?\d*|\bor\s+\d+\s*=\s*\d+"
            r"|\bsleep\s*\(\s*\d+|\bbenchmark\s*\(|information_schema|;\s*drop\s+table)",
            re.IGNORECASE,
        ),
    ),
    "xss": (
        Severity.MEDIUM,
        re.compile(
            r"(<\s*script|javascript:|\bon(?:error|load|mouseover|focus)\s*=|<\s*(?:svg|img|iframe)\b)",
            re.IGNORECASE,
        ),
    ),
    "path_traversal": (
        Severity.HIGH,
        re.compile(r"(\.\./|\.\.\\|/etc/(?:passwd|shadow)|/proc/self/|win\.ini|boot\.ini)", re.I),
    ),
    "command_injection": (
        Severity.CRITICAL,
        re.compile(r"(?:;|\||`|\$\(|&&)\s*(?:cat|id|whoami|uname|wget|curl|nc|bash|sh|ping)\b", re.I),
    ),
    "sensitive_file_probe": (
        Severity.LOW,
        re.compile(
            r"/(?:\.env|\.git/(?:config|HEAD)|\.htpasswd|wp-config\.php(?:\.bak)?|\.DS_Store"
            r"|id_rsa|backup\.(?:sql|zip|tar\.gz)|phpinfo\.php)(?:[?#]|$)",
            re.IGNORECASE,
        ),
    ),
}


def decode_path(path: str) -> str:
    """URL-decode twice to defeat simple double-encoding evasion."""
    return unquote_plus(unquote_plus(path))


@dataclass
class WebAttackDetector(Detector):
    name: ClassVar[str] = "web_attack"
    rule_id: ClassVar[str] = "LS-WEB-001"
    title: ClassVar[str] = "Web application attack"
    mitre: ClassVar[str] = "T1190"
    description: ClassVar[str] = (
        "Signature match for SQLi, XSS, path traversal, command injection or secret-file probes. "
        "Severity is escalated one level if any matching request got a 2xx response."
    )

    min_hits: int = 1

    def detect(self, events: list[Event]) -> list[Finding]:
        hits: dict[tuple[str, str], list[Event]] = defaultdict(list)
        for event in events:
            if event.source != "http" or not event.path:
                continue
            decoded = decode_path(event.path)
            for category, (_, pattern) in WEB_SIGNATURES.items():
                if pattern.search(decoded):
                    hits[(event.ip, category)].append(event)

        findings = []
        for (ip, category), evs in hits.items():
            if len(evs) < self.min_hits:
                continue
            severity = WEB_SIGNATURES[category][0]
            successes = sum(1 for e in evs if e.status is not None and 200 <= e.status < 300)
            if successes:
                severity = severity.escalate()
            label = category.replace("_", " ")
            findings.append(
                self._finding(
                    ip,
                    evs,
                    severity,
                    {
                        "category": category,
                        "responses_2xx": successes,
                        "sample_paths": [decode_path(e.path or "") for e in evs[:MAX_EVIDENCE]],
                    },
                    title=f"Web attack: {label}",
                )
            )
        return findings


@dataclass
class ContentDiscoveryDetector(Detector):
    name: ClassVar[str] = "content_discovery"
    rule_id: ClassVar[str] = "LS-WEB-002"
    title: ClassVar[str] = "Directory / content brute-forcing"
    mitre: ClassVar[str] = "T1595.003"
    description: ClassVar[str] = "A burst of 404 responses from one IP (wordlist scanning)."

    not_found_threshold: int = 20
    window_seconds: int = 60

    def detect(self, events: list[Event]) -> list[Finding]:
        window = timedelta(seconds=self.window_seconds)
        findings = []
        misses = group_by_ip(events, lambda e: e.source == "http" and e.status == 404)
        for ip, evs in misses.items():
            peak = peak_in_window([e.timestamp for e in evs], window)
            if peak < self.not_found_threshold:
                continue
            findings.append(
                self._finding(
                    ip,
                    evs,
                    Severity.MEDIUM,
                    {
                        "total_404": len(evs),
                        "peak_in_window": peak,
                        "window_seconds": self.window_seconds,
                        "distinct_paths": len({e.path for e in evs}),
                    },
                )
            )
        return findings


SCANNER_UA = re.compile(
    r"(sqlmap|nikto|nmap|masscan|zgrab|gobuster|dirbuster|feroxbuster|ffuf|wfuzz|wpscan"
    r"|nuclei|acunetix|nessus|openvas|hydra|whatweb)",
    re.IGNORECASE,
)


@dataclass
class ScannerUserAgentDetector(Detector):
    name: ClassVar[str] = "scanner_user_agent"
    rule_id: ClassVar[str] = "LS-WEB-003"
    title: ClassVar[str] = "Known offensive tool user-agent"
    mitre: ClassVar[str] = "T1595.002"
    description: ClassVar[str] = "Requests whose User-Agent identifies a known scanner."

    min_hits: int = 1

    def detect(self, events: list[Event]) -> list[Finding]:
        findings = []
        matches = group_by_ip(
            events,
            lambda e: e.source == "http" and bool(e.user_agent and SCANNER_UA.search(e.user_agent)),
        )
        for ip, evs in matches.items():
            if len(evs) < self.min_hits:
                continue
            tools = sorted({m.group(1).lower() for e in evs if (m := SCANNER_UA.search(e.user_agent or ""))})
            findings.append(self._finding(ip, evs, Severity.LOW, {"tools": tools}))
        return findings


@dataclass
class RequestFloodDetector(Detector):
    name: ClassVar[str] = "request_flood"
    rule_id: ClassVar[str] = "LS-WEB-004"
    title: ClassVar[str] = "HTTP request flood"
    mitre: ClassVar[str] = "T1499"
    description: ClassVar[str] = "Request rate from a single IP far above normal."

    threshold: int = 300
    window_seconds: int = 60

    def detect(self, events: list[Event]) -> list[Finding]:
        window = timedelta(seconds=self.window_seconds)
        findings = []
        for ip, evs in group_by_ip(events, lambda e: e.source == "http").items():
            peak = peak_in_window([e.timestamp for e in evs], window)
            if peak < self.threshold:
                continue
            severity = Severity.HIGH if peak >= self.threshold * 3 else Severity.MEDIUM
            top = Counter(e.path for e in evs).most_common(3)
            findings.append(
                self._finding(
                    ip,
                    evs,
                    severity,
                    {
                        "total_requests": len(evs),
                        "peak_in_window": peak,
                        "window_seconds": self.window_seconds,
                        "top_paths": dict(top),
                    },
                )
            )
        return findings


REGISTRY: dict[str, type[Detector]] = {
    cls.name: cls
    for cls in (
        BruteForceDetector,
        UserEnumerationDetector,
        CompromiseDetector,
        WebAttackDetector,
        ContentDiscoveryDetector,
        ScannerUserAgentDetector,
        RequestFloodDetector,
    )
}
