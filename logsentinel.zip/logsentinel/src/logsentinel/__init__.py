"""LogSentinel - a lightweight, dependency-free log-based intrusion detector."""

from .config import Config, build_config, load_config
from .engine import AnalysisResult, analyze
from .models import Event, Finding, Severity

__version__ = "0.1.0"

__all__ = [
    "AnalysisResult",
    "Config",
    "Event",
    "Finding",
    "Severity",
    "__version__",
    "analyze",
    "build_config",
    "load_config",
]
