"""Render analysis results as terminal text, JSON or a self-contained HTML page."""

from __future__ import annotations

import html
import json

from .engine import AnalysisResult
from .models import Finding, Severity

_ANSI = {
    Severity.CRITICAL: "\033[1;97;41m",
    Severity.HIGH: "\033[1;31m",
    Severity.MEDIUM: "\033[33m",
    Severity.LOW: "\033[36m",
    Severity.INFO: "\033[2m",
}
_RESET = "\033[0m"
_DIM = "\033[2m"
_BOLD = "\033[1m"


def _fmt_ts(f: Finding) -> str:
    return f.first_seen.strftime("%Y-%m-%d %H:%M:%S")


def _detail_line(f: Finding) -> str:
    parts = []
    for key, value in f.details.items():
        if isinstance(value, dict):
            value = ", ".join(f"{k}×{v}" for k, v in value.items()) or "-"
        elif isinstance(value, list):
            value = ", ".join(str(v) for v in value) or "-"
        parts.append(f"{key}={value}")
    return "; ".join(parts)


def render_text(result: AnalysisResult, *, color: bool = True) -> str:
    def c(code: str, text: str) -> str:
        return f"{code}{text}{_RESET}" if color else text

    s = result.stats
    counts = result.severity_counts()
    summary = ", ".join(f"{n} {name.lower()}" for name, n in counts.items() if n) or "none"
    lines = [
        c(_BOLD, f"LogSentinel - {len(result.findings)} finding(s): {summary}"),
        c(
            _DIM,
            f"Parsed {s.lines_total:,} lines -> {s.events:,} events "
            f"({s.unparsed:,} unrecognised) from {len(result.inputs)} input(s)",
        ),
        "",
    ]
    if not result.findings:
        lines.append("No suspicious activity detected.")
        return "\n".join(lines)

    header = f"{'SEVERITY':<9} {'RULE':<11} {'SOURCE IP':<16} {'COUNT':>6}  {'FIRST SEEN (UTC)':<19}  TITLE"
    lines += [c(_BOLD, header), "-" * len(header)]
    for f in result.findings:
        sev = c(_ANSI[f.severity], f"{f.severity.name:<9}")
        lines.append(f"{sev} {f.rule_id:<11} {f.ip:<16} {f.count:>6}  {_fmt_ts(f):<19}  {f.title}")
        mitre = f"  [ATT&CK {f.mitre}]" if f.mitre else ""
        lines.append(c(_DIM, f"{'':<9} └─ {_detail_line(f)}{mitre}"))
    return "\n".join(lines)


def render_json(result: AnalysisResult) -> str:
    return json.dumps(result.to_dict(), indent=2, ensure_ascii=False)


_CSS = """
:root{--bg:#0f1115;--panel:#171a21;--line:#262b36;--text:#e6e8ee;--muted:#8b93a7;
--critical:#ff4d6d;--high:#ff8c42;--medium:#f6c343;--low:#4cc9f0;--info:#8b93a7}
*{box-sizing:border-box}body{margin:0;font:14px/1.5 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;
background:var(--bg);color:var(--text)}main{max-width:1200px;margin:0 auto;padding:32px 20px}
h1{margin:0 0 4px;font-size:24px}.muted{color:var(--muted)}
.cards{display:grid;grid-template-columns:repeat(5,1fr);gap:12px;margin:24px 0}
.card{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:14px}
.card b{display:block;font-size:26px}.card span{color:var(--muted);font-size:12px;letter-spacing:.06em}
table{width:100%;border-collapse:collapse;background:var(--panel);border:1px solid var(--line);border-radius:10px;overflow:hidden}
th,td{padding:10px 12px;text-align:left;border-bottom:1px solid var(--line);vertical-align:top}
th{font-size:12px;color:var(--muted);text-transform:uppercase;letter-spacing:.06em}
td.num{text-align:right;font-variant-numeric:tabular-nums}code,pre{font-family:ui-monospace,Consolas,monospace;font-size:12px}
pre{white-space:pre-wrap;word-break:break-all;background:#0b0d11;padding:10px;border-radius:6px;margin:8px 0 0}
.sev{display:inline-block;padding:2px 8px;border-radius:999px;font-size:11px;font-weight:700;color:#111}
.CRITICAL{background:var(--critical);color:#fff}.HIGH{background:var(--high)}.MEDIUM{background:var(--medium)}
.LOW{background:var(--low)}.INFO{background:var(--info)}
details summary{cursor:pointer;color:var(--muted)}dl{display:grid;grid-template-columns:max-content 1fr;gap:2px 12px;margin:8px 0 0}
dt{color:var(--muted)}dd{margin:0}a{color:var(--low)}td.nw,td code{white-space:nowrap}
@media(max-width:700px){.cards{grid-template-columns:repeat(2,1fr)}}
"""


def _fmt_value(value: object) -> str:
    if isinstance(value, dict):
        return ", ".join(f"{k} ({v})" for k, v in value.items()) or "-"
    if isinstance(value, list):
        return ", ".join(str(v) for v in value) or "-"
    return str(value)


def render_html(result: AnalysisResult) -> str:
    e = html.escape
    counts = result.severity_counts()
    cards = "".join(f'<div class="card"><span>{name}</span><b>{n}</b></div>' for name, n in counts.items())
    rows = []
    for f in result.findings:
        details = "".join(f"<dt>{e(k)}</dt><dd>{e(_fmt_value(v))}</dd>" for k, v in f.details.items())
        evidence = e("\n".join(f.evidence))
        mitre = (
            f'<a href="https://attack.mitre.org/techniques/{e(f.mitre.replace(".", "/"))}/" '
            f'target="_blank" rel="noopener">{e(f.mitre)}</a>'
            if f.mitre
            else "-"
        )
        rows.append(
            f"<tr><td><span class='sev {f.severity.name}'>{f.severity.name}</span></td>"
            f"<td><code>{e(f.rule_id)}</code></td><td><code>{e(f.ip)}</code></td>"
            f"<td class='num'>{f.count}</td><td class='nw'>{e(_fmt_ts(f))}</td><td>{mitre}</td>"
            f"<td><b>{e(f.title)}</b><details><summary>details &amp; evidence</summary>"
            f"<dl>{details}</dl><pre>{evidence}</pre></details></td></tr>"
        )
    body = "".join(rows) if rows else "<tr><td colspan='7'>No suspicious activity detected.</td></tr>"
    s = result.stats
    return f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>LogSentinel report</title><style>{_CSS}</style></head>
<body><main>
<h1>LogSentinel report</h1>
<div class="muted">Generated {e(result.generated_at.strftime("%Y-%m-%d %H:%M:%S UTC"))} ·
{s.lines_total:,} lines → {s.events:,} events ({s.unparsed:,} unrecognised) ·
inputs: {e(", ".join(result.inputs))}</div>
<div class="cards">{cards}</div>
<table><thead><tr><th>Severity</th><th>Rule</th><th>Source IP</th><th>Count</th>
<th>First seen (UTC)</th><th>ATT&amp;CK</th><th>Finding</th></tr></thead>
<tbody>{body}</tbody></table>
</main></body></html>
"""


RENDERERS = {"text": render_text, "json": render_json, "html": render_html}
