"""Load and validate TOML configuration."""

from __future__ import annotations

import ipaddress
import tomllib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .detectors import REGISTRY, ConfigError, Detector

IPNetwork = ipaddress.IPv4Network | ipaddress.IPv6Network


@dataclass
class Config:
    detectors: list[Detector]
    allowlist: list[IPNetwork] = field(default_factory=list)

    def is_allowed(self, ip: str) -> bool:
        addr = ipaddress.ip_address(ip)
        return any(addr in net for net in self.allowlist)


def build_config(data: dict[str, Any]) -> Config:
    unknown = set(data) - set(REGISTRY) - {"allowlist"}
    if unknown:
        raise ConfigError(
            f"unknown config section(s): {', '.join(sorted(unknown))}. "
            f"Valid sections: allowlist, {', '.join(REGISTRY)}"
        )

    detectors: list[Detector] = []
    for name, cls in REGISTRY.items():
        section = dict(data.get(name, {}))
        enabled = section.pop("enabled", True)
        if not isinstance(enabled, bool):
            raise ConfigError(f"[{name}] 'enabled' must be true or false")
        if not enabled:
            continue
        bad = set(section) - set(cls.option_names())
        if bad:
            raise ConfigError(
                f"[{name}] unknown option(s): {', '.join(sorted(bad))}. "
                f"Valid options: enabled, {', '.join(cls.option_names())}"
            )
        detectors.append(cls(**section))

    allow_section = data.get("allowlist", {})
    networks = []
    for entry in allow_section.get("networks", []):
        try:
            networks.append(ipaddress.ip_network(entry, strict=False))
        except ValueError as exc:
            raise ConfigError(f"[allowlist] invalid network {entry!r}: {exc}") from exc
    return Config(detectors=detectors, allowlist=networks)


def load_config(path: str | Path | None) -> Config:
    if path is None:
        return build_config({})
    try:
        with open(path, "rb") as fh:
            data = tomllib.load(fh)
    except FileNotFoundError as exc:
        raise ConfigError(f"config file not found: {path}") from exc
    except tomllib.TOMLDecodeError as exc:
        raise ConfigError(f"invalid TOML in {path}: {exc}") from exc
    return build_config(data)
