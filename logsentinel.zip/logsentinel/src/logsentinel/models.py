"""Core data types shared across parsers, detectors and reporters."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import IntEnum
from typing import Any


class Severity(IntEnum):
    """Ordered severity levels. Higher value = more urgent."""

    INFO = 10
    LOW = 20
    MEDIUM = 30
    HIGH = 40
    CRITICAL = 50

    @classmethod
    def parse(cls, value: str) -> Severity:
        try:
            return cls[value.strip().upper()]
        except KeyError as exc:
            valid = ", ".join(s.name.lower() for s in cls)
            raise ValueError(f"unknown severity {value!r} (expected one of: {valid})") from exc

    def escalate(self) -> Severity:
        """Return the next level up, capped at CRITICAL."""
        return Severity(min(self.value + 10, Severity.CRITICAL.value))


@dataclass(frozen=True, slots=True)
class Event:
    """A single normalised security-relevant log event."""

    timestamp: datetime  # always timezone-aware, UTC
    source: str  # "ssh" | "http"
    ip: str
    action: str  # "auth_failure" | "auth_success" | "invalid_user" | "http_request"
    user: str | None = None
    method: str | None = None
    path: str | None = None
    status: int | None = None
    user_agent: str | None = None
    raw: str = ""


@dataclass(slots=True)
class Finding:
    """A detection produced by a detector, ready to be reported."""

    rule_id: str
    title: str
    severity: Severity
    ip: str
    first_seen: datetime
    last_seen: datetime
    count: int
    mitre: str | None = None
    details: dict[str, Any] = field(default_factory=dict)
    evidence: list[str] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "rule_id": self.rule_id,
            "title": self.title,
            "severity": self.severity.name,
            "ip": self.ip,
            "first_seen": self.first_seen.isoformat(),
            "last_seen": self.last_seen.isoformat(),
            "count": self.count,
            "mitre_attack": self.mitre,
            "details": self.details,
            "evidence": self.evidence,
        }
