"""Log line parsers.

Supported formats (auto-detected per line):

* OpenSSH via syslog  -- classic ``Nov 10 03:12:01 host sshd[123]: ...``
* OpenSSH via rsyslog -- ISO-8601 ``2026-11-10T03:12:01+05:30 host sshd[123]: ...``
* Nginx / Apache "combined" access log format

Every parser returns a normalised :class:`~logsentinel.models.Event` with a
timezone-aware UTC timestamp, or ``None`` when the line is not recognised.
"""

from __future__ import annotations

import ipaddress
import re
from datetime import UTC, datetime

from .models import Event

# --- SSH -------------------------------------------------------------------

_SYSLOG_PREFIX = re.compile(
    r"^(?P<ts>[A-Z][a-z]{2}\s+\d{1,2}\s\d{2}:\d{2}:\d{2})\s+\S+\s+sshd(?:\[\d+\])?:\s+(?P<msg>.*)$"
)
_ISO_PREFIX = re.compile(
    r"^(?P<ts>\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?)"
    r"\s+\S+\s+sshd(?:\[\d+\])?:\s+(?P<msg>.*)$"
)

_SSH_MESSAGES: tuple[tuple[str, re.Pattern[str]], ...] = (
    (
        "auth_failure",
        re.compile(
            r"^Failed (?:password|publickey|keyboard-interactive/pam) for "
            r"(?:invalid user )?(?P<user>\S*) from (?P<ip>\S+) port \d+"
        ),
    ),
    (
        "auth_success",
        re.compile(
            r"^Accepted (?:password|publickey|keyboard-interactive/pam) for "
            r"(?P<user>\S+) from (?P<ip>\S+) port \d+"
        ),
    ),
    ("invalid_user", re.compile(r"^Invalid user (?P<user>\S*) from (?P<ip>\S+)")),
)

# --- HTTP ------------------------------------------------------------------

_COMBINED = re.compile(
    r"^(?P<ip>\S+) \S+ \S+ \[(?P<ts>[^\]]+)\] "
    r'"(?P<method>[A-Z]+) (?P<path>\S+)(?: [^"]*)?" '
    r"(?P<status>\d{3}) (?:\d+|-)"
    r'(?: "(?P<referer>[^"]*)" "(?P<ua>[^"]*)")?'
)


def _valid_ip(value: str) -> str | None:
    try:
        return str(ipaddress.ip_address(value))
    except ValueError:
        return None


def _parse_syslog_ts(value: str, year: int) -> datetime:
    # Syslog omits the year and timezone; we assume the given year and UTC.
    naive = datetime.strptime(f"{year} {' '.join(value.split())}", "%Y %b %d %H:%M:%S")
    return naive.replace(tzinfo=UTC)


def _parse_iso_ts(value: str) -> datetime:
    dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    return dt.astimezone(UTC)


def parse_ssh(line: str, year: int) -> Event | None:
    if m := _SYSLOG_PREFIX.match(line):
        try:
            ts = _parse_syslog_ts(m["ts"], year)
        except ValueError:
            return None
    elif m := _ISO_PREFIX.match(line):
        try:
            ts = _parse_iso_ts(m["ts"])
        except ValueError:
            return None
    else:
        return None

    msg = m["msg"]
    for action, pattern in _SSH_MESSAGES:
        if mm := pattern.match(msg):
            ip = _valid_ip(mm["ip"])
            if ip is None:
                return None
            return Event(
                timestamp=ts,
                source="ssh",
                ip=ip,
                action=action,
                user=mm["user"] or None,
                raw=line,
            )
    return None


def parse_http(line: str) -> Event | None:
    m = _COMBINED.match(line)
    if not m:
        return None
    ip = _valid_ip(m["ip"])
    if ip is None:
        return None
    try:
        ts = datetime.strptime(m["ts"], "%d/%b/%Y:%H:%M:%S %z").astimezone(UTC)
    except ValueError:
        return None
    ua = m["ua"]
    return Event(
        timestamp=ts,
        source="http",
        ip=ip,
        action="http_request",
        method=m["method"],
        path=m["path"],
        status=int(m["status"]),
        user_agent=None if ua in (None, "-") else ua,
        raw=line,
    )


def parse_line(line: str, year: int) -> Event | None:
    """Auto-detect the format of ``line`` and parse it."""
    line = line.rstrip("\r\n")
    if not line.strip():
        return None
    return parse_ssh(line, year) or parse_http(line)
