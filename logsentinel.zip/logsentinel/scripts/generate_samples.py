"""Generate deterministic, realistic sample logs for demos and tests.

All IPs come from the RFC 5737 documentation ranges (192.0.2.0/24,
198.51.100.0/24, 203.0.113.0/24), so no real host is ever implicated.

    python scripts/generate_samples.py            # writes samples/auth.log, samples/access.log
"""

from __future__ import annotations

import random
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import quote

OUT = Path(__file__).resolve().parent.parent / "samples"
START = datetime(2026, 11, 10, 2, 0, 0)
rng = random.Random(1337)


# --- auth.log --------------------------------------------------------------

def syslog(ts: datetime, msg: str, pid: int) -> tuple[datetime, str]:
    return ts, f"{ts:%b} {ts.day:>2} {ts:%H:%M:%S} web01 sshd[{pid}]: {msg}"


def auth_lines() -> list[str]:
    out: list[tuple[datetime, str]] = []
    pid = 4000

    # Normal admin activity
    for i in range(8):
        ts = START + timedelta(minutes=12 * i, seconds=rng.randint(0, 50))
        pid += 1
        out.append(syslog(ts, f"Accepted publickey for deploy from 192.0.2.10 port {rng.randint(40000, 60000)} ssh2", pid))
        out.append(syslog(ts + timedelta(seconds=1), "pam_unix(sshd:session): session opened for user deploy(uid=1001) by (uid=0)", pid))

    # A human typo: two failures then success - must NOT be flagged
    ts = START + timedelta(minutes=30)
    for k in range(2):
        out.append(syslog(ts + timedelta(seconds=6 * k), f"Failed password for alice from 192.0.2.11 port 51022 ssh2", 4500))
    out.append(syslog(ts + timedelta(seconds=15), "Accepted password for alice from 192.0.2.11 port 51022 ssh2", 4500))

    # Brute force against root that eventually succeeds -> HIGH + CRITICAL
    ts = START + timedelta(minutes=47)
    for k in range(42):
        pid += 1
        out.append(syslog(ts + timedelta(seconds=2 * k + rng.random()), f"Failed password for root from 203.0.113.5 port {rng.randint(30000, 65000)} ssh2", pid))
    out.append(syslog(ts + timedelta(seconds=90), "Accepted password for root from 203.0.113.5 port 58211 ssh2", pid + 1))

    # Slow username spraying -> enumeration only (stays under brute-force rate)
    users = ["admin", "test", "oracle", "ubuntu", "pi", "postgres", "git", "jenkins", "ftpuser", "support"]
    ts = START + timedelta(hours=1, minutes=10)
    for k, user in enumerate(users):
        pid += 1
        t = ts + timedelta(seconds=17 * k)
        out.append(syslog(t, f"Invalid user {user} from 198.51.100.23 port {rng.randint(30000, 65000)}", pid))
        out.append(syslog(t + timedelta(seconds=2), f"Failed password for invalid user {user} from 198.51.100.23 port {rng.randint(30000, 65000)} ssh2", pid))

    # Noise sshd lines the parser should skip
    out.append(syslog(START + timedelta(hours=2), "Received disconnect from 192.0.2.10 port 50122:11: disconnected by user", 9001))
    out.append(syslog(START + timedelta(hours=2, seconds=5), "Server listening on 0.0.0.0 port 22.", 9002))

    out.sort(key=lambda x: x[0])
    return [line for _, line in out]


# --- access.log ------------------------------------------------------------

BROWSER = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36"


def combined(ts: datetime, ip: str, method: str, path: str, status: int, ua: str) -> tuple[datetime, str]:
    aware = ts.replace(tzinfo=timezone.utc)
    size = rng.randint(120, 18000) if status == 200 else rng.randint(100, 600)
    return ts, f'{ip} - - [{aware:%d/%b/%Y:%H:%M:%S %z}] "{method} {path} HTTP/1.1" {status} {size} "-" "{ua}"'


def access_lines() -> list[str]:
    out: list[tuple[datetime, str]] = []
    pages = ["/", "/products", "/products/42", "/about", "/static/app.css", "/static/app.js", "/contact", "/api/cart"]

    # Normal visitors
    for i in range(220):
        ip = f"192.0.2.{rng.randint(20, 90)}"
        ts = START + timedelta(seconds=rng.randint(0, 3 * 3600))
        out.append(combined(ts, ip, "GET", rng.choice(pages), 200, BROWSER))

    # Directory brute-forcing with gobuster -> LS-WEB-002 + LS-WEB-003
    words = ["admin", "backup", "old", "test", "dev", "api/v1", "phpmyadmin", "uploads", "private", "cgi-bin",
             "server-status", "config", "db", "logs", "tmp", "install", "setup", "dashboard", "portal", "staging"]
    ts = START + timedelta(minutes=20)
    for k in range(75):
        path = "/" + words[k % len(words)] + ("" if k < 20 else f"{k}")
        out.append(combined(ts + timedelta(milliseconds=400 * k), "198.51.100.77", "GET", path, 404, "gobuster/3.6"))

    # SQL injection with sqlmap, one request returns 200 -> escalated
    sqli = ["1' OR '1'='1", "1 UNION SELECT username,password FROM users--", "1 AND SLEEP(5)", "1; DROP TABLE users"]
    ts = START + timedelta(minutes=55)
    for k, payload in enumerate(sqli):
        status = 200 if k == 1 else 500
        out.append(combined(ts + timedelta(seconds=3 * k), "203.0.113.44", "GET", f"/products?id={quote(payload)}", status, "sqlmap/1.8.2#stable (https://sqlmap.org)"))

    # Path traversal that succeeds, XSS, secret-file probes, command injection
    ts = START + timedelta(hours=1, minutes=35)
    ip = "203.0.113.61"
    out.append(combined(ts, ip, "GET", "/download?file=" + quote("../../../../etc/passwd"), 200, BROWSER))
    out.append(combined(ts + timedelta(seconds=4), ip, "GET", "/search?q=" + quote(quote("<script>alert(document.cookie)</script>")), 200, BROWSER))
    out.append(combined(ts + timedelta(seconds=8), ip, "GET", "/.env", 404, BROWSER))
    out.append(combined(ts + timedelta(seconds=9), ip, "GET", "/.git/config", 404, BROWSER))
    out.append(combined(ts + timedelta(seconds=14), ip, "GET", "/ping?host=" + quote("127.0.0.1; cat /etc/passwd"), 500, BROWSER))

    # Request flood on the login endpoint -> LS-WEB-004
    ts = START + timedelta(hours=2, minutes=5)
    for k in range(420):
        out.append(combined(ts + timedelta(milliseconds=120 * k), "198.51.100.200", "POST", "/api/login", 401, "python-requests/2.32"))

    out.sort(key=lambda x: x[0])
    return [line for _, line in out]


def main() -> None:
    OUT.mkdir(exist_ok=True)
    (OUT / "auth.log").write_text("\n".join(auth_lines()) + "\n", encoding="utf-8")
    (OUT / "access.log").write_text("\n".join(access_lines()) + "\n", encoding="utf-8")
    print(f"wrote samples to {OUT}")


if __name__ == "__main__":
    main()
