import gzip
import json

from logsentinel.cli import main


def test_scan_json(samples, capsys):
    code = main(
        ["scan", str(samples / "auth.log"), str(samples / "access.log"), "-f", "json", "--year", "2026"]
    )
    assert code == 0
    report = json.loads(capsys.readouterr().out)
    rules = {(f["rule_id"], f["ip"]) for f in report["findings"]}
    assert ("LS-SSH-003", "203.0.113.5") in rules
    assert ("LS-SSH-001", "203.0.113.5") in rules
    assert ("LS-SSH-002", "198.51.100.23") in rules
    assert ("LS-WEB-002", "198.51.100.77") in rules
    assert ("LS-WEB-004", "198.51.100.200") in rules
    # the legitimate user who mistyped twice must never appear
    assert not any(f["ip"] == "192.0.2.11" for f in report["findings"])
    assert report["summary"]["CRITICAL"] >= 1


def test_fail_on_sets_exit_code(samples, capsys):
    assert main(["scan", str(samples / "auth.log"), "--fail-on", "critical"]) == 1
    assert main(["scan", str(samples / "auth.log"), "--min-severity", "critical", "--fail-on", "none"]) == 0


def test_html_output_is_escaped(samples, tmp_path):
    out = tmp_path / "r.html"
    assert main(["scan", str(samples / "access.log"), "-f", "html", "-o", str(out)]) == 0
    page = out.read_text()
    assert page.startswith("<!DOCTYPE html>")
    assert "<script>alert" not in page
    assert "&lt;script&gt;alert" in page


def test_gzip_input(samples, tmp_path, capsys):
    gz = tmp_path / "auth.log.gz"
    gz.write_bytes(gzip.compress((samples / "auth.log").read_bytes()))
    assert main(["scan", str(gz), "-f", "json"]) == 0
    assert json.loads(capsys.readouterr().out)["stats"]["events"] > 0


def test_allowlist_suppresses_findings(samples, tmp_path, capsys):
    cfg = tmp_path / "c.toml"
    cfg.write_text('[allowlist]\nnetworks = ["203.0.113.0/24"]\n')
    main(["scan", str(samples / "auth.log"), "-c", str(cfg), "-f", "json"])
    findings = json.loads(capsys.readouterr().out)["findings"]
    assert all(not f["ip"].startswith("203.0.113.") for f in findings)


def test_errors_return_2(tmp_path, capsys):
    assert main(["scan", str(tmp_path / "missing.log")]) == 2
    bad = tmp_path / "bad.toml"
    bad.write_text("[brute_force]\nthreshold = -1\n")
    assert main(["scan", "-", "-c", str(bad)]) == 2


def test_rules_command(capsys):
    assert main(["rules"]) == 0
    assert "LS-SSH-001" in capsys.readouterr().out
