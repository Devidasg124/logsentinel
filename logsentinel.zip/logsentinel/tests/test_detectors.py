from datetime import timedelta

from conftest import T0, http, ssh

from logsentinel.detectors import (
    BruteForceDetector,
    CompromiseDetector,
    ContentDiscoveryDetector,
    RequestFloodDetector,
    ScannerUserAgentDetector,
    UserEnumerationDetector,
    WebAttackDetector,
    peak_in_window,
)
from logsentinel.models import Severity


def test_peak_in_window_sliding():
    times = [T0 + timedelta(seconds=s) for s in (0, 10, 20, 100, 101, 102, 103)]
    assert peak_in_window(times, timedelta(seconds=5)) == 4
    assert peak_in_window(times, timedelta(seconds=20)) == 4
    assert peak_in_window(times, timedelta(seconds=200)) == 7


def test_brute_force_triggers_at_threshold():
    events = [ssh(i * 5, "203.0.113.5") for i in range(5)]
    [finding] = BruteForceDetector(threshold=5, window_seconds=60).detect(events)
    assert finding.severity == Severity.MEDIUM
    assert finding.details["peak_in_window"] == 5


def test_brute_force_ignores_slow_failures():
    events = [ssh(i * 61, "203.0.113.5") for i in range(10)]
    assert BruteForceDetector(threshold=5, window_seconds=60).detect(events) == []


def test_brute_force_escalates_to_high():
    events = [ssh(i, "203.0.113.5") for i in range(20)]
    [finding] = BruteForceDetector(threshold=5).detect(events)
    assert finding.severity == Severity.HIGH


def test_user_enumeration():
    users = ["admin", "test", "oracle", "pi"]
    events = [ssh(i * 30, "198.51.100.23", "invalid_user", u) for i, u in enumerate(users)]
    [finding] = UserEnumerationDetector(distinct_users=4, window_seconds=300).detect(events)
    assert finding.details["distinct_users_total"] == 4


def test_user_enumeration_window_expires_old_users():
    users = ["a", "b", "c", "d"]
    events = [ssh(i * 200, "198.51.100.23", "invalid_user", u) for i, u in enumerate(users)]
    assert UserEnumerationDetector(distinct_users=4, window_seconds=300).detect(events) == []


def test_compromise_after_failures_is_critical():
    events = [ssh(i, "203.0.113.5") for i in range(6)] + [ssh(30, "203.0.113.5", "auth_success")]
    [finding] = CompromiseDetector(failure_threshold=5).detect(events)
    assert finding.severity == Severity.CRITICAL
    assert finding.details == {"user": "root", "failures_before_success": 6, "lookback_seconds": 3600}
    assert finding.first_seen == events[0].timestamp


def test_compromise_ignores_typos_and_other_ips():
    events = [
        ssh(0, "192.0.2.11", user="alice"),
        ssh(5, "192.0.2.11", user="alice"),
        ssh(10, "192.0.2.11", "auth_success", "alice"),
        *[ssh(20 + i, "203.0.113.5") for i in range(10)],
        ssh(40, "192.0.2.99", "auth_success"),
    ]
    assert CompromiseDetector(failure_threshold=5).detect(events) == []


def test_compromise_respects_lookback():
    events = [ssh(i, "203.0.113.5") for i in range(6)] + [ssh(7200, "203.0.113.5", "auth_success")]
    assert CompromiseDetector(failure_threshold=5, lookback_seconds=3600).detect(events) == []


def test_web_attack_categories_and_double_encoding():
    events = [
        http(0, "203.0.113.44", "/p?id=1%2520UNION%2520SELECT%2520pass", 500),
        http(1, "203.0.113.61", "/dl?f=..%2F..%2Fetc%2Fpasswd", 200),
        http(2, "203.0.113.61", "/q?s=%3Cscript%3Ealert(1)%3C/script%3E", 404),
        http(3, "192.0.2.50", "/products/42?sort=price", 200),
    ]
    found = {(f.ip, f.details["category"]): f for f in WebAttackDetector().detect(events)}
    assert set(found) == {
        ("203.0.113.44", "sql_injection"),
        ("203.0.113.61", "path_traversal"),
        ("203.0.113.61", "xss"),
    }
    # traversal got a 200 -> escalated from HIGH to CRITICAL
    assert found[("203.0.113.61", "path_traversal")].severity == Severity.CRITICAL
    assert found[("203.0.113.61", "xss")].severity == Severity.MEDIUM


def test_web_attack_no_false_positive_on_normal_traffic():
    benign = [
        "/",
        "/about",
        "/search?q=union+station+hotels",
        "/blog/or-maybe-not",
        "/static/app.js",
        "/api/items?limit=10&offset=20",
    ]
    events = [http(i, "192.0.2.1", p) for i, p in enumerate(benign)]
    assert WebAttackDetector().detect(events) == []


def test_content_discovery():
    events = [http(i * 0.5, "198.51.100.77", f"/w{i}", 404) for i in range(25)]
    [finding] = ContentDiscoveryDetector(not_found_threshold=20).detect(events)
    assert finding.details["distinct_paths"] == 25


def test_scanner_user_agent():
    events = [http(0, "203.0.113.44", ua="sqlmap/1.8"), http(1, "192.0.2.1", ua=None)]
    [finding] = ScannerUserAgentDetector().detect(events)
    assert finding.details["tools"] == ["sqlmap"]


def test_request_flood():
    events = [http(i * 0.1, "198.51.100.200", "/api/login", 401) for i in range(350)]
    [finding] = RequestFloodDetector(threshold=300).detect(events)
    assert finding.severity == Severity.MEDIUM
