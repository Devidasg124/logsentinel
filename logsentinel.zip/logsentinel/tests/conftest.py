from datetime import UTC, datetime, timedelta
from pathlib import Path

import pytest

from logsentinel.models import Event

SAMPLES = Path(__file__).resolve().parent.parent / "samples"
T0 = datetime(2026, 11, 10, 3, 0, 0, tzinfo=UTC)


def at(seconds: float) -> datetime:
    return T0 + timedelta(seconds=seconds)


def ssh(seconds: float, ip: str, action: str = "auth_failure", user: str = "root") -> Event:
    return Event(timestamp=at(seconds), source="ssh", ip=ip, action=action, user=user, raw=f"{action} {user}")


def http(
    seconds: float, ip: str, path: str = "/", status: int = 200, ua: str | None = "Mozilla/5.0"
) -> Event:
    return Event(
        timestamp=at(seconds),
        source="http",
        ip=ip,
        action="http_request",
        method="GET",
        path=path,
        status=status,
        user_agent=ua,
        raw=f"GET {path} {status}",
    )


@pytest.fixture
def samples() -> Path:
    return SAMPLES
