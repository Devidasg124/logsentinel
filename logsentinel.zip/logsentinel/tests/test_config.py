import pytest

from logsentinel.config import build_config, load_config
from logsentinel.detectors import REGISTRY, ConfigError


def test_defaults_enable_every_detector():
    assert {d.name for d in build_config({}).detectors} == set(REGISTRY)


def test_disable_and_override():
    cfg = build_config({"brute_force": {"threshold": 10}, "request_flood": {"enabled": False}})
    names = {d.name: d for d in cfg.detectors}
    assert "request_flood" not in names
    assert names["brute_force"].threshold == 10


@pytest.mark.parametrize(
    "data",
    [
        {"nope": {}},
        {"brute_force": {"treshold": 5}},
        {"brute_force": {"threshold": 0}},
        {"brute_force": {"threshold": "5"}},
        {"brute_force": {"enabled": "yes"}},
        {"allowlist": {"networks": ["10.0.0.0/33"]}},
    ],
)
def test_invalid_config_rejected(data):
    with pytest.raises(ConfigError):
        build_config(data)


def test_allowlist():
    cfg = build_config({"allowlist": {"networks": ["10.0.0.0/8", "2001:db8::/32"]}})
    assert cfg.is_allowed("10.2.3.4")
    assert cfg.is_allowed("2001:db8::5")
    assert not cfg.is_allowed("203.0.113.5")


def test_bundled_rules_file_loads():
    from pathlib import Path

    cfg = load_config(Path(__file__).resolve().parent.parent / "rules" / "default.toml")
    assert len(cfg.detectors) == len(REGISTRY)
