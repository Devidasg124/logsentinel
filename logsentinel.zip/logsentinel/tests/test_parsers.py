from datetime import UTC, datetime

import pytest

from logsentinel.parsers import parse_line


def test_ssh_failed_password_invalid_user():
    line = "Nov 10 03:12:01 web01 sshd[1234]: Failed password for invalid user admin from 203.0.113.5 port 52344 ssh2"
    ev = parse_line(line, 2026)
    assert ev is not None
    assert (ev.source, ev.action, ev.user, ev.ip) == ("ssh", "auth_failure", "admin", "203.0.113.5")
    assert ev.timestamp == datetime(2026, 11, 10, 3, 12, 1, tzinfo=UTC)


def test_ssh_single_digit_day_padding():
    ev = parse_line(
        "Nov  3 01:02:03 h sshd[1]: Accepted publickey for deploy from 192.0.2.10 port 1 ssh2", 2026
    )
    assert ev is not None and ev.action == "auth_success" and ev.timestamp.day == 3


def test_ssh_iso_timestamp_converted_to_utc():
    line = (
        "2026-11-10T08:42:01.123+05:30 web01 sshd[9]: Failed password for root from 2001:db8::1 port 22 ssh2"
    )
    ev = parse_line(line, 1999)
    assert ev is not None
    assert ev.timestamp == datetime(2026, 11, 10, 3, 12, 1, 123000, tzinfo=UTC)
    assert ev.ip == "2001:db8::1"


def test_ssh_invalid_user_line():
    ev = parse_line("Nov 10 03:12:00 h sshd[5]: Invalid user oracle from 198.51.100.23 port 4444", 2026)
    assert ev is not None and ev.action == "invalid_user" and ev.user == "oracle"


def test_http_combined_format():
    line = (
        '203.0.113.9 - - [10/Nov/2026:08:50:11 +0530] "GET /wp-login.php?x=1 HTTP/1.1" 404 153 "-" "curl/8.0"'
    )
    ev = parse_line(line, 2026)
    assert ev is not None
    assert (ev.method, ev.path, ev.status, ev.user_agent) == ("GET", "/wp-login.php?x=1", 404, "curl/8.0")
    assert ev.timestamp == datetime(2026, 11, 10, 3, 20, 11, tzinfo=UTC)


def test_http_dash_user_agent_is_none():
    line = '192.0.2.1 - - [10/Nov/2026:03:00:00 +0000] "GET / HTTP/1.1" 200 10 "-" "-"'
    ev = parse_line(line, 2026)
    assert ev is not None and ev.user_agent is None


@pytest.mark.parametrize(
    "line",
    [
        "",
        "random garbage",
        "Nov 10 03:12:01 web01 sshd[1]: Server listening on 0.0.0.0 port 22.",
        "Nov 10 03:12:01 web01 sshd[1]: Failed password for root from not-an-ip port 1 ssh2",
        '999.1.1.1 - - [10/Nov/2026:03:00:00 +0000] "GET / HTTP/1.1" 200 10 "-" "-"',
        "Nov 10 03:12:01 web01 cron[1]: Failed password for root from 1.2.3.4 port 1 ssh2",
    ],
)
def test_unrecognised_lines_return_none(line):
    assert parse_line(line, 2026) is None
